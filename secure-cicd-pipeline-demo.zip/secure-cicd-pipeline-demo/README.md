# Secure CI/CD Pipeline Demo

[![CI/CD Pipeline](https://github.com/Artilleryjoe/secure-cicd-pipeline-demo/actions/workflows/ci-cd.yml/badge.svg)](https://github.com/Artilleryjoe/secure-cicd-pipeline-demo/actions/workflows/ci-cd.yml)
[![Trivy](https://img.shields.io/badge/Trivy-scanned-brightgreen)](https://github.com/Artilleryjoe/secure-cicd-pipeline-demo/security/code-scanning)
[![CodeQL](https://img.shields.io/badge/CodeQL-enabled-blue)](https://github.com/Artilleryjoe/secure-cicd-pipeline-demo/security/code-scanning)

This repository demonstrates a **security-first CI/CD pipeline** using GitHub Actions. It was built as part of a take-home challenge for a Cybersecurity Operations Engineer role. The application is intentionally minimal so the focus stays on the pipeline itself: testing, static analysis, containerization, vulnerability scanning, and secure deployment.

## The Application

A tiny Flask web service with two endpoints:

- `GET /` — Returns a JSON greeting confirming the pipeline is operational and hardened.
- `GET /health` — Simple health check for container orchestration and monitoring readiness.

The code prioritizes secure defaults (no debug in prod, non-root container, etc.).

## Pipeline Overview

The single workflow (`.github/workflows/ci-cd.yml`) runs on every push and PR to `main`. It consists of three jobs that run in parallel where possible:

1. **Lint & Test** (`lint-and-test`)
   - Sets up Python 3.12
   - Runs **Ruff** for linting (includes many security rules similar to Bandit) and formatting checks
   - Executes **pytest** unit tests

2. **CodeQL SAST Analysis** (`codeql-analysis`)
   - Uses the official `github/codeql-action` to perform static application security testing on the Python code
   - Results appear in the repository's **Security > Code scanning** tab
   - Queries include security-and-quality pack

3. **Build, Container Scan & Deploy** (`build-scan-deploy`)
   - Triggered only on pushes to `main` (not PRs)
   - Uses Docker Buildx + BuildKit for efficient, cached, multi-platform capable builds
   - Builds a **multi-stage, non-root Docker image** (see Dockerfile for security hardening details)
   - Pushes the image to **GitHub Container Registry (GHCR)** — this is the deploy step
   - Runs **Trivy** vulnerability scanner on the built image (CRITICAL/HIGH/MEDIUM severity)
   - Uploads Trivy SARIF results to GitHub Security tab for unified vulnerability management
   - Includes BuildKit provenance and SBOM attestation for supply chain security

### Why These Tools?

- **Ruff**: Extremely fast, modern replacement for flake8 + isort + Black + many security plugins. Native SARIF/GitHub integration.
- **CodeQL**: Best-in-class SAST engine (powers GitHub Advanced Security). Excellent Python support and low false positives.
- **Trivy**: Lightweight, fast, comprehensive (OS packages, language deps, secrets, misconfigurations, IaC). Native SARIF upload.
- **Docker Buildx + GHCR**: Industry standard for container delivery. Multi-stage + non-root drastically reduces attack surface.
- **Dependabot**: Weekly automated PRs for dependency and Action updates (see `.github/dependabot.yml`).

## Repository Security Hardening (Beyond Workflows)

In addition to the pipeline, the following **repository settings** (Security tab) are recommended / enabled for this demo:

- **Secret scanning** + **Push protection** (prevents accidental commit of tokens, keys, etc.)
- **Code scanning** (CodeQL + Trivy results surface here)
- **Dependabot alerts** and **Dependabot security updates**
- **Private vulnerability reporting**
- **Branch protection rules** on `main`:
  - Require status checks to pass (the three jobs above)
  - Require pull request reviews before merging
  - Require signed commits (optional but recommended)
  - Restrict who can push to main

These settings turn the repository itself into a hardened asset.

## How to Reproduce / Run Locally

```bash
# Clone
git clone https://github.com/Artilleryjoe/secure-cicd-pipeline-demo.git
cd secure-cicd-pipeline-demo

# Local Python run (dev)
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python -m app.main

# Or with Docker (recommended)
docker build -t secure-cicd-demo .
docker run --rm -p 8000:8000 secure-cicd-demo

# Test endpoints
curl http://localhost:8000/
curl http://localhost:8000/health
```

## Pipeline Execution Evidence

After pushing changes, visit the **Actions** tab. You will see successful runs of the workflow with all jobs green. The Security tab will show CodeQL and Trivy findings (base image may have some low/medium items; the app code itself is clean).

## If I Had Another Week (Production Hardening Ideas)

- **Image signing & attestation**: Add `cosign` to sign images and create SLSA provenance attestations (verify in deployment).
- **SBOM generation & storage**: Use `syft` + attach to GHCR or upload to dependency graph.
- **Policy as Code**: Integrate `conftest` or OPA/Gatekeeper checks in pipeline.
- **Runtime security**: Add Falco or Tetragon rules if deploying to Kubernetes.
- **GitOps deployment**: Add a deploy job that updates a Kubernetes manifest or Argo CD Application (with Kustomize/Helm) and uses OIDC for auth.
- **More blocking**: Make Trivy `exit-code: 1` on HIGH/CRITICAL in non-demo environments; add SAST blocking on new findings.
- **Infrastructure as Code security**: If Terraform/CloudFormation added, scan with `checkov` or `tfsec`.
- **Supply chain**: Enable SLSA Level 2/3 build provenance via GitHub's native support.

I intentionally kept scope tight to "a few hours" while still demonstrating real, production-applicable security practices.

## Connection to My Work

The security principles here (defense-in-depth in delivery, least privilege, continuous scanning, SBOM/provenance) directly inform my broader projects, including the **Kusanagi-CCO** research platform for counter-cognitive operations and cognitive defense (see my other repositories). Securing the pipeline is foundational to securing the systems we build and operate.

## Questions / Contact

Built by Kris McCoy (Artilleryjoe) for the UT Austin ISO Cybersecurity Operations Engineer challenge — June 2026.

---

*This README is written to be onboarding-friendly for a new teammate.*
