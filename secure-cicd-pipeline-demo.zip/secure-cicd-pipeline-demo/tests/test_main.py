import pytest
from app.main import app


@pytest.fixture
def client():
    """Flask test client fixture."""
    app.config["TESTING"] = True
    with app.test_client() as client:
        yield client


def test_index_returns_secure_message(client):
    """Test the main endpoint returns expected secure pipeline message."""
    response = client.get("/")
    assert response.status_code == 200
    data = response.get_json()
    assert "secure CI/CD pipeline" in data["message"]
    assert data["security"] == "pipeline-hardened"


def test_health_check(client):
    """Test health endpoint for container readiness."""
    response = client.get("/health")
    assert response.status_code == 200
    data = response.get_json()
    assert data["status"] == "healthy"
