from flask import Flask, jsonify

app = Flask(__name__)

@app.route("/")
def index():
    """Main endpoint - returns a secure greeting."""
    return jsonify(
        message="Hello from a secure CI/CD pipeline!",
        status="operational",
        security="pipeline-hardened"
    )

@app.route("/health")
def health():
    """Health check endpoint for container orchestration and monitoring."""
    return jsonify(status="healthy", timestamp="dynamic"), 200

if __name__ == "__main__":
    # For local dev only; production uses gunicorn
    app.run(host="0.0.0.0", port=8000, debug=False)
