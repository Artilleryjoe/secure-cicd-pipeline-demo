# Secure CI/CD Pipeline Demo - Flask Application
# This minimal app demonstrates secure delivery practices.